import pygame
import math
pygame.init()
window = pygame.display.set_mode((800, 800))
pygame.display.set_caption("Nova Zone")

# Assets
bg = pygame.image.load("Space.jfif")
fighter = pygame.image.load('Space fighter.png')
fighter = pygame.transform.scale(fighter, (84, 50))
fighter2 = pygame.image.load("Fighter 2.png")
fighter2 = pygame.transform.scale(fighter2, (40, 50))
fighter2 = pygame.transform.rotate(fighter2, 90)
phaser = pygame.image.load("Phaser.png")
phaser = pygame.transform.scale(phaser, (25, 25))

# Colours
Black = (0, 0, 0)
Red = (255, 0, 0)
Green = (0, 255, 0)
Blue = (0, 0, 255)
clock = pygame.time.Clock()
phasers = []

# Player shiz nit
class player(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.health = 100
        self.vel = 0
        self.angle = 0

    def draw(self, texture):  # By using the Rot angle and the velocity we can use trig to make move diagonally

        texture = pygame.transform.rotate(texture, self.angle)
        self.x += math.cos(math.radians(self.angle)) * self.vel
        self.y -= math.sin(math.radians(self.angle)) * self.vel
        window.blit(texture, (self.x, self.y))
        if self.vel > 0:  # Deceleration
            self.vel -= 2
        elif self.vel < 0:
            self.vel += 2


class Spirit(object):  # NPC
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.health = 100
        self.vel = 0
        self.angle = 0

    def draw(self, texture):  # Ditto player draw basically
        texture = pygame.transform.rotate(texture, self.angle)
        self.x += math.cos(math.radians(self.angle)) * self.vel
        self.y -= math.sin(math.radians(self.angle)) * self.vel
        window.blit(texture, (self.x, self.y))
        if self.vel > 0:
            self.vel -= 2
        elif self.vel < 0:
            self.vel += 2

    def fight(self):  # WIP AI
        if self.x != player.x and self.y != player.y:
            tx = player.x - self.x
            ty = player.y - self.x
            # Debug lines
            pygame.draw.line(window, Red, (self.x, self.y), (player.x, self.y))
            pygame.draw.line(window, Green, (player.x, self.y), (player.x, self.y + ty))
            pygame.draw.line(window, Blue, (self.x, self.y), (player.x, player.y))

            adjacent = player.x - self.x
            opposite = player.y + self.y - ty

            # SohCahToa
            #print(opposite, adjacent)
            self.angle = math.degrees(math.atan(opposite/adjacent))
            #print(self.angle)

class Bullet(object):  # Player bullets
    def __init__(self, x, y, angle):
        self.x = x
        self.y = y
        self.width = 5
        self.height = 5
        self.vel = 5
        self.angle = angle

    def draw(self, texture):  # Ditto player
        texture = pygame.transform.rotate(texture, self.angle)
        self.x += math.cos(math.radians(self.angle)) * self.vel
        self.y -= math.sin(math.radians(self.angle)) * self.vel
        window.blit(texture, (self.x, self.y))





def redraw():  # Handles all drawing
    window.blit(bg, (0, 0))
    F1.fight()
    player.draw(fighter)
    F1.draw(fighter2)
    for character in phasers:  # Handles all bullets individually from the list
        character.draw(phaser)
    pygame.display.update()


player = player(200, 600, 32, 32)
F1 = Spirit(300, 300, 10, 10)
run = True
while run:
    clock.tick(60)
    pygame.time.delay(100)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    # Movement keys
    if keys[pygame.K_LEFT]:  # Rotation
        player.angle += 5


    if keys[pygame.K_RIGHT]:  # Rotation
        player.angle -= 5

    if keys[pygame.K_UP]:  # Acceleration
        player.vel += 4


    if keys[pygame.K_DOWN]:  # Decleration
        player.vel -= 4

    # Angle boundaries for movement calculations
    if player.angle > 360:
        player.angle = 0
    elif player.angle < 0:
        player.angle = 360

    if keys[pygame.K_SPACE]: # FIRE
        phasers.append(Bullet(player.x, player.y+10, player.angle))

    redraw()


pygame.quit()